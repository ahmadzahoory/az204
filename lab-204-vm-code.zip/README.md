Ahmad Majeed Zahoory
====================
